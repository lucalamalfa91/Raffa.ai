# Contigo — Information architecture (web V1) · **V2 — pilot path**

> V2 supersedes the Day-1 10-stop tour. Source: `uploads/percorso-pilota-v1.md`. Prototype: `Contigo V2.dc.html`.

## Thesis
Two primaries — **Documents** (feed the knowledge base) and **Ask Contigo** (query it). Everything else is a satellite that lights up from the validated knowledge base and hands off to Ask.

## Navigation (left rail)
**Primary**
1. Documents — upload, processing, review queue (Review is a *state* of Documents, not a rail item)
2. Ask Contigo (⌘K)

**From your knowledge base** (dimmed until the first `completed` document)
3. Portfolio
4. Renewals
5. Home (3 KPIs + opportunities)
6. Quote check (optional, never hero)

**Footer**: Workspace & members (admin only), user.

Global: Ask bar on every satellite screen (disabled with an explanatory placeholder until KB ready); Contract 360 carries a contract-scoped Ask sidebar instead. One engine, three surfaces.

## Onboarding (first run)
Entra sign-in → no workspace → create (company / industry / country) → **Documents empty hero**: "First we feed the knowledge base. Then you ask." with the 01 Upload · 02 Process · 03 Ask strip and a single CTA **Upload contracts**. No invite in the hero. Confidence is explained inline the first time the user sees a weak field (dismissible callout in Review). Invite appears after the first validated document.

## Route map
| Route | Screen | Notes |
|---|---|---|
| /signin | Entra → create workspace / enter | fixtures=seeded skips creation |
| /documents | Hero (empty) · dropzone + document list · Review sub-view | statuses processing → needs review → completed / failed |
| /ask | Ask Contigo | off-state until KB ready |
| /contracts/:id | Contract 360 — Overview · Clauses · Documents · More ▾ (7 more tabs) + Ask sidebar | landing for every citation |
| /portfolio | Compact table, "More columns" toggle | empty → Documents |
| /renewals | Priority list + "why it is here" card | empty → Documents |
| / (home) | 3 KPIs + opportunities | empty → Documents |
| /quotes | Optional one-screen quote check | sample only |
| /workspace | Members + invite | nudge: invite after first validated doc |

## Ask contract
- Auth before retrieve; answers only from `completed` documents.
- Structured (dates, spend, counts) vs RAG (clauses); route line shown under each answer.
- Every answer cites doc · page · § → Contract 360 (Documents or Clauses tab, passage highlighted) — or abstains.
- Screen context: on a contract the sidebar is scoped; two contextual suggestion chips per screen.


---

# Archive — V1 Day-1 IA

# Contigo — Information architecture (web V1)

## Roles on the Day-1 path
- **Workspace Admin** — everything below + Workspace & members.
- **Procurement** — everything below except member management (sees a "request access" state).
- Legal / Finance / Read-only exist in the permission model; not separate nav variants in V1.

## Navigation (left rail)
1. Home (Savings KPIs + opportunities) — R3
2. Portfolio — R1
3. Renewals — R2
4. Ask Contigo (⌘K) — R1
5. Quote check — R4
6. Documents (upload + processing status) — R0
7. Review queue — R1
8. Workspace & members (admin only) — R0

Global: Ask bar on every screen; user + sign out in rail footer.

## Route map
| Route | Screen | Primary object |
|---|---|---|
| /signin | Entra sign-in → workspace picker | Tenant |
| /workspace/members | Members & roles, invite | User, Role |
| /documents | Upload + document list + status | Document |
| /contracts | Portfolio (attention strip, filters, table) | Contract |
| /contracts/:id | Contract 360 — tabs Overview · Commercials · Products · Clauses · Obligations · Risks · Documents · Benchmark · Renewal · Activity | Contract + children |
| /contracts/:id/review | Field review / correction with evidence pane | Extraction, Correction |
| /ask | Ask Contigo — chat, citations, abstain | Query |
| /renewals | Pipeline: threshold strip, priority table, insight card + actions | Renewal |
| / (home) | Savings KPIs + opportunities | SavingsOpportunity |
| /quotes/:id | Quote check stepper: Extract → Assessment → Target → Negotiation (+ outcome) | Quote, NegotiationOutcome |

## Object model → screens
- Contract → Portfolio row, Contract 360, Review, Renewal row, Savings opportunity, Ask citation target.
- Document → Documents list, Contract 360 › Documents, Evidence pane.
- Renewal → Renewals row + insight card; Contract 360 › Renewal tab.
- SavingsOpportunity → Home table; created from Renewal action or Quote outcome.
- Quote → Quote check; outcome feeds Savings Realized.

## Cross-links (all implemented in the prototype)
- Document row → Contract 360.
- Portfolio row → Contract 360 › Overview.
- Contract 360 "Review extraction" → Review; "Open in renewals" → Renewals with contract selected.
- Review "Mark as validated" → Contract 360.
- Ask citation chip → Contract 360 › Clauses.
- Renewal action → creates opportunity → visible on Home; "Open Contract 360" → Renewal tab.
- Home opportunity row → Contract 360 › Benchmark (or Quote check for quote-type).
- Quote outcome → "See it on Home".

## Day-1 path (single clickable flow)
Sign in → pick workspace → invite Procurement user → upload contract → processing → needs_review → review 2 critical fields → Contract 360 → Ask a question with citations (+ one abstain) → Renewals: act on Salesforce → Home shows opportunity → Quote check: map SKU → assessment → target → negotiation → record outcome → Home Savings Realized updates.
